package com.ryn.camera.data.capability

import com.ryn.camera.domain.model.DeviceReport
import org.json.JSONObject

object ReportFormatter {
    fun toText(r: DeviceReport): String {
        val sb = StringBuilder("RYN CAMERA - CAMERA DIAGNOSTICS\n")
        render(r.toMap(), 0, sb)
        return sb.toString()
    }

    fun toJson(r: DeviceReport): String = JSONObject(r.toMap()).toString(2)

    private fun render(map: Map<*, *>, indent: Int, sb: StringBuilder) {
        val pad = "  ".repeat(indent)
        for ((k, v) in map) {
            when (v) {
                is Map<*, *> -> { sb.append(pad).append(k).append(":\n"); render(v, indent + 1, sb) }
                is List<*> -> {
                    if (v.isNotEmpty() && v.all { it is Map<*, *> }) {
                        sb.append(pad).append(k).append(":\n")
                        v.forEachIndexed { i, m ->
                            sb.append(pad).append("  [").append(i).append("]\n")
                            render(m as Map<*, *>, indent + 2, sb)
                        }
                    } else {
                        sb.append(pad).append(k).append(": ")
                            .append(if (v.isEmpty()) "-" else v.joinToString(", ")).append('\n')
                    }
                }
                is Boolean -> sb.append(pad).append(k).append(": ").append(if (v) "Ya" else "Tidak").append('\n')
                null -> sb.append(pad).append(k).append(": -\n")
                else -> sb.append(pad).append(k).append(": ").append(v).append('\n')
            }
        }
    }
}
