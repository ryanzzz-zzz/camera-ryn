package com.ryn.camera.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.ryn.camera.R
import com.ryn.camera.databinding.ActivityMainBinding
import com.ryn.camera.domain.model.DeviceReport
import com.ryn.camera.domain.profile.ResolvedProfile
import com.ryn.camera.ui.diagnostics.DiagnosticsActivity
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val vm: MainViewModel by viewModels()

    // Scan tidak butuh izin; izin diminta di awal agar siap untuk tahap kamera.
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.scan() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvStatus.setText(R.string.optimizing)
        binding.btnDiagnostics.setOnClickListener {
            startActivity(Intent(this, DiagnosticsActivity::class.java))
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) { vm.state.collect { render(it) } }
        }

        if (savedInstanceState == null) {
            val missing = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isEmpty()) vm.scan() else permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun render(state: ScanState) {
        when (state) {
            ScanState.Idle -> Unit
            ScanState.Scanning -> {
                binding.tvStatus.setText(R.string.optimizing)
                binding.progress.visibility = View.VISIBLE
            }
            is ScanState.Done -> {
                binding.tvTitle.setText(R.string.app_name)
                binding.tvStatus.setText(R.string.profile_ready)
                binding.progress.visibility = View.GONE
                binding.scroll.visibility = View.VISIBLE
                binding.btnDiagnostics.visibility = View.VISIBLE
                binding.tvSummary.text = summary(state.report, state.profile)
            }
            is ScanState.Failed -> {
                binding.progress.visibility = View.GONE
                binding.tvStatus.text = state.message
            }
        }
    }

    private fun yn(b: Boolean) = if (b) "Ya" else "Tidak didukung perangkat"

    private fun summary(r: DeviceReport, p: ResolvedProfile): String {
        val back = r.cameras.firstOrNull { it.id == p.backCameraId }
        val sb = StringBuilder()
        sb.append("Perangkat: ${r.manufacturer} ${r.model}\n")
        sb.append("Android ${r.release} (API ${r.sdk})\n")
        sb.append("Profil: ${p.profileName}\n\n")
        sb.append("Kamera terdeteksi: ${r.cameras.joinToString { "${it.id}(${it.facing})" }.ifEmpty { "-" }}\n")
        if (back != null) {
            sb.append("Hardware level: ${back.hardwareLevel}\n")
            sb.append("OIS hardware: ${yn(back.ois)}\n")
            sb.append("EIS native: ${yn(back.hasEis)}\n")
            sb.append("HDR hardware: ${yn(back.hdrScene)}\n")
            sb.append("RAW: ${yn(back.raw)}\n")
            sb.append("Flash: ${yn(back.flash)}\n")
        }
        sb.append("Gyroscope: ${yn(r.sensors.any { it.label == "gyroscope" && it.available })}\n")
        sb.append("Accelerometer: ${yn(r.sensors.any { it.label == "accelerometer" && it.available })}\n\n")
        sb.append("Video aman: ${p.videoSize} @ ${p.videoFps} FPS, ${p.videoBitrateBps / 1_000_000} Mbps (H.264)\n")
        p.notes.forEach { sb.append("• ").append(it).append('\n') }
        sb.append("\nAntarmuka kamera hadir di Tahap 2. Buka Camera Diagnostics untuk detail lengkap.")
        return sb.toString()
    }
}
