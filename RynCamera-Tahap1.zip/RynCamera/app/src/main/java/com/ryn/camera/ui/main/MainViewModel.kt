package com.ryn.camera.ui.main

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ryn.camera.core.RynLog
import com.ryn.camera.data.capability.CapabilityDetector
import com.ryn.camera.domain.model.DeviceReport
import com.ryn.camera.domain.profile.DeviceProfiles
import com.ryn.camera.domain.profile.ResolvedProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface ScanState {
    object Idle : ScanState
    object Scanning : ScanState
    data class Done(val report: DeviceReport, val profile: ResolvedProfile) : ScanState
    data class Failed(val message: String) : ScanState
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow<ScanState>(ScanState.Idle)
    val state: StateFlow<ScanState> = _state.asStateFlow()

    fun scan() {
        if (_state.value is ScanState.Scanning || _state.value is ScanState.Done) return
        _state.value = ScanState.Scanning
        viewModelScope.launch {
            try {
                val start = SystemClock.elapsedRealtime()
                val report = withContext(Dispatchers.Default) { CapabilityDetector(getApplication()).detect() }
                val wait = 1200L - (SystemClock.elapsedRealtime() - start)
                if (wait > 0) delay(wait)
                val profile = DeviceProfiles.select().resolve(report)
                RynLog.i("Profil: ${profile.profileName} ${profile.videoSize}@${profile.videoFps}")
                _state.value = ScanState.Done(report, profile)
            } catch (e: Exception) {
                RynLog.e("Scan gagal", e)
                _state.value = ScanState.Failed("Scan kamera gagal: ${e.javaClass.simpleName}")
            }
        }
    }
}
