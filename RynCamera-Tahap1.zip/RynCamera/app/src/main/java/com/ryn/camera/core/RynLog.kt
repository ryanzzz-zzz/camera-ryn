package com.ryn.camera.core

import android.util.Log

/** Logger internal developer. Tidak menyimpan data pribadi. */
object RynLog {
    private const val TAG = "RynCamera"
    private const val MAX = 300
    private val buffer = ArrayDeque<String>()

    @Synchronized
    private fun add(level: String, msg: String) {
        if (buffer.size >= MAX) buffer.removeFirst()
        buffer.addLast("${System.currentTimeMillis()} $level $msg")
    }

    fun i(msg: String) { Log.i(TAG, msg); add("I", msg) }
    fun w(msg: String) { Log.w(TAG, msg); add("W", msg) }
    fun e(msg: String, t: Throwable? = null) {
        Log.e(TAG, msg, t); add("E", msg + (t?.let { " (${it.javaClass.simpleName})" } ?: ""))
    }

    @Synchronized
    fun dump(): String = buffer.joinToString("\n")
}
