package com.ryn.camera.domain.profile

import android.os.Build
import com.ryn.camera.domain.model.DeviceReport

/** Hasil profil setelah dicocokkan dengan kemampuan hardware yang BENAR-BENAR terdeteksi. */
data class ResolvedProfile(
    val profileName: String,
    val backCameraId: String?,
    val frontCameraId: String?,
    val videoSize: String,
    val videoFps: Int,
    val videoBitrateBps: Int,
    val videoMime: String,
    val fps60Candidate: Boolean,
    val allow60Fps: Boolean,
    val processingStrength: Float,
    val bitmapPoolMb: Int,
    val thermalWarnC: Float,
    val thermalReduceC: Float,
    val notes: List<String>
)

/** Profil perangkat. Nilai di sini hanya BATAS AMAN; selalu di-clamp oleh hasil deteksi. */
open class DeviceProfile(
    val id: String,
    val displayName: String,
    private val safeWidth: Int,
    private val safeHeight: Int,
    private val safeFps: Int,
    private val targetBitrateBps: Int,
    private val processingStrength: Float,
    private val bitmapPoolMb: Int,
    private val thermalWarnC: Float,
    private val thermalReduceC: Float
) {
    fun resolve(report: DeviceReport): ResolvedProfile {
        val notes = mutableListOf<String>()
        val backs = report.cameras.filter { it.facing == "BACK" }
        val back = backs.firstOrNull { it.id == "0" } ?: backs.firstOrNull()
        val front = report.cameras.firstOrNull { it.facing == "FRONT" }

        if (back == null) notes += "Kamera belakang tidak terdeteksi."
        if (front == null) notes += "Kamera depan tidak terdeteksi."

        var w = safeWidth
        var h = safeHeight
        if (back != null && !back.videoSizes.contains("${w}x$h")) {
            val best = back.videoSizes.mapNotNull { parse(it) }
                .filter { it.first <= w && it.second <= h }
                .maxByOrNull { it.first * it.second }
            if (best != null) {
                w = best.first; h = best.second
                notes += "${safeWidth}x$safeHeight tidak tersedia; memakai ${w}x$h."
            } else notes += "Resolusi video aman tidak ditemukan."
        }

        val maxFps = back?.maxFps ?: safeFps
        val fps = minOf(safeFps, maxOf(maxFps, 1))
        val cand = back?.fps60Candidate == true
        notes += if (cand)
            "Ada indikasi 60 FPS, belum diaktifkan sampai terverifikasi saat uji rekam (Tahap 3)."
        else "60 FPS tidak didukung hardware perangkat."

        if (back != null && !back.ois) notes += "OIS hardware tidak ada: memakai Software Stabilization."
        if (back != null && !back.hasEis) notes += "EIS native tidak tersedia."

        val avcMax = report.codecs.filter { it.mime == "video/avc" }.maxOfOrNull { it.bitrateMaxBps }
        val bitrate = if (avcMax != null && avcMax > 0) minOf(targetBitrateBps, avcMax) else targetBitrateBps

        return ResolvedProfile(
            displayName, back?.id, front?.id, "${w}x$h", fps, bitrate, "video/avc",
            cand, false, processingStrength, bitmapPoolMb, thermalWarnC, thermalReduceC, notes
        )
    }

    private fun parse(s: String): Pair<Int, Int>? {
        val p = s.split("x")
        val a = p.getOrNull(0)?.toIntOrNull() ?: return null
        val b = p.getOrNull(1)?.toIntOrNull() ?: return null
        return a to b
    }
}

object RealmeC53Profile : DeviceProfile(
    id = "realme_c53", displayName = "realme C53 NFC",
    safeWidth = 1920, safeHeight = 1080, safeFps = 30,
    targetBitrateBps = 16_000_000,
    processingStrength = 0.6f, bitmapPoolMb = 48,
    thermalWarnC = 41f, thermalReduceC = 44f
)

object GenericProfile : DeviceProfile(
    id = "generic", displayName = "Generic device",
    safeWidth = 1920, safeHeight = 1080, safeFps = 30,
    targetBitrateBps = 12_000_000,
    processingStrength = 0.5f, bitmapPoolMb = 32,
    thermalWarnC = 41f, thermalReduceC = 44f
)

object DeviceProfiles {
    fun select(model: String = Build.MODEL ?: ""): DeviceProfile =
        if (model.startsWith("RMX376", ignoreCase = true) || model.contains("C53", ignoreCase = true))
            RealmeC53Profile else GenericProfile
}
