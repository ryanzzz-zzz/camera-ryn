package com.ryn.camera.ui.diagnostics

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ryn.camera.R
import com.ryn.camera.core.RynLog
import com.ryn.camera.data.capability.CapabilityDetector
import com.ryn.camera.data.capability.ReportFormatter
import com.ryn.camera.databinding.ActivityDiagnosticsBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DiagnosticsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDiagnosticsBinding
    private var textReport: String = ""
    private var jsonReport: String = ""

    private val saveTxt =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { write(it, textReport) }
    private val saveJson =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { write(it, jsonReport) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDiagnosticsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvReport.text = getString(R.string.optimizing)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnTxt.setOnClickListener { saveTxt.launch("ryn_diagnostics.txt") }
        binding.btnJson.setOnClickListener { saveJson.launch("ryn_diagnostics.json") }

        lifecycleScope.launch {
            try {
                val report = withContext(Dispatchers.Default) { CapabilityDetector(applicationContext).detect() }
                textReport = ReportFormatter.toText(report)
                jsonReport = ReportFormatter.toJson(report)
                binding.tvReport.text = textReport
                binding.btnTxt.isEnabled = true
                binding.btnJson.isEnabled = true
            } catch (e: Exception) {
                RynLog.e("Diagnostics gagal", e)
                binding.tvReport.text = "Diagnostics gagal: ${e.javaClass.simpleName}"
            }
        }
    }

    private fun write(uri: Uri?, content: String) {
        if (uri == null) return
        val ok = try {
            contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) } != null
        } catch (e: Exception) {
            RynLog.e("Export gagal", e); false
        }
        Toast.makeText(this, if (ok) R.string.export_ok else R.string.export_fail, Toast.LENGTH_SHORT).show()
    }
}
