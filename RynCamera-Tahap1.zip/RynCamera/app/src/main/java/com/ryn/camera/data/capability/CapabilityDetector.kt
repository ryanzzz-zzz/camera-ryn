package com.ryn.camera.data.capability

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.params.DynamicRangeProfiles
import android.media.CamcorderProfile
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.os.Build
import android.os.PowerManager
import android.util.Range
import com.ryn.camera.core.RynLog
import com.ryn.camera.domain.model.CamcorderInfo
import com.ryn.camera.domain.model.CameraReport
import com.ryn.camera.domain.model.CodecReport
import com.ryn.camera.domain.model.DeviceReport
import com.ryn.camera.domain.model.SensorReport
import java.util.Locale

/** Mendeteksi kemampuan kamera/codec/sensor secara nyata dari API perangkat. Tidak ada asumsi. */
class CapabilityDetector(private val context: Context) {

    fun detect(): DeviceReport {
        val errors = mutableListOf<String>()
        val cameras = readCameras(errors)
        val codecs = readCodecs(errors)
        val sensors = readSensors(errors)
        RynLog.i("Scan selesai: ${cameras.size} kamera, ${codecs.size} codec, ${errors.size} error")
        return DeviceReport(
            manufacturer = Build.MANUFACTURER ?: "-", brand = Build.BRAND ?: "-",
            model = Build.MODEL ?: "-", device = Build.DEVICE ?: "-",
            hardware = Build.HARDWARE ?: "-", sdk = Build.VERSION.SDK_INT,
            release = Build.VERSION.RELEASE ?: "-", abis = Build.SUPPORTED_ABIS.toList(),
            thermalStatus = readThermal(),
            cameras = cameras, codecs = codecs, sensors = sensors,
            errors = errors, timestamp = System.currentTimeMillis()
        )
    }

    // ---------------------------------------------------------------- cameras

    private fun readCameras(errors: MutableList<String>): List<CameraReport> {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        if (cm == null) { errors.add("CameraManager tidak tersedia"); return emptyList() }
        val ids = try { cm.cameraIdList.toList() } catch (e: Exception) {
            RynLog.e("cameraIdList gagal", e)
            errors.add("cameraIdList gagal: ${e.javaClass.simpleName}")
            return emptyList()
        }
        return ids.mapNotNull { id ->
            try { readCamera(cm, id) } catch (e: Exception) {
                RynLog.e("Baca kamera $id gagal", e)
                errors.add("Kamera $id: ${e.javaClass.simpleName}")
                null
            }
        }
    }

    private fun readCamera(cm: CameraManager, id: String): CameraReport {
        val c = cm.getCameraCharacteristics(id)
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)

        val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
            CameraCharacteristics.LENS_FACING_BACK -> "BACK"
            CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
            CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
            else -> "UNKNOWN"
        }
        val hw = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
            else -> "UNKNOWN"
        }
        val capInts = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
        val caps = capInts.map { capName(it) }

        val pa = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
        val focals = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.toList() ?: emptyList()
        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true

        val af = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.map { afName(it) } ?: emptyList()
        val awb = c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.map { awbName(it) } ?: emptyList()

        val aeRange = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        val aeStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)
        val iso = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val exp = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)

        val fpsRanges: List<Range<Int>> =
            c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList()
        val maxFps = fpsRanges.maxOfOrNull { it.upper } ?: 0

        val videoSizes = (map?.getOutputSizes(MediaRecorder::class.java)?.toList() ?: emptyList())
            .sortedByDescending { it.width * it.height }
        val has1080 = videoSizes.any { it.width == 1920 && it.height == 1080 }

        val highSpeed = mutableListOf<String>()
        try {
            map?.highSpeedVideoSizes?.forEach { s ->
                val r = map.getHighSpeedVideoFpsRangesFor(s).joinToString("/") { "${it.lower}-${it.upper}" }
                highSpeed.add("${s.width}x${s.height}@$r")
            }
        } catch (e: Exception) { RynLog.w("highSpeed query gagal: ${e.javaClass.simpleName}") }

        val photoSizes = (map?.getOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList())
            .sortedByDescending { it.width * it.height }.take(6).map { "${it.width}x${it.height}" }
        val formats = map?.outputFormats?.map { formatName(it) } ?: emptyList()

        val ois = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
            ?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        val stabInts = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.toList() ?: emptyList()
        val eisModes = stabInts.map {
            when (it) { 0 -> "OFF"; 1 -> "ON"; 2 -> "PREVIEW_STABILIZATION"; else -> "MODE_$it" }
        }
        val hasEis = stabInts.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)

        val hdrScene = c.get(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES)
            ?.contains(CameraMetadata.CONTROL_SCENE_MODE_HDR) == true
        val dyn = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            c.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)?.supportedProfiles?.forEach {
                dyn.add(
                    when (it) {
                        DynamicRangeProfiles.STANDARD -> "STANDARD"
                        DynamicRangeProfiles.HLG10 -> "HLG10"
                        DynamicRangeProfiles.HDR10 -> "HDR10"
                        DynamicRangeProfiles.HDR10_PLUS -> "HDR10_PLUS"
                        else -> "PROFILE_$it"
                    }
                )
            }
        }
        val zoom = if (Build.VERSION.SDK_INT >= 30)
            c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let { "${it.lower}..${it.upper}" } ?: "-"
        else "tidak tersedia (API<30)"
        val physical = if (Build.VERSION.SDK_INT >= 28) c.physicalCameraIds.toList() else emptyList()

        val camcorder = mutableListOf<CamcorderInfo>()
        val idInt = id.toIntOrNull()
        if (idInt != null) {
            listOf(
                "2160p" to CamcorderProfile.QUALITY_2160P,
                "1080p" to CamcorderProfile.QUALITY_1080P,
                "720p" to CamcorderProfile.QUALITY_720P
            ).forEach { (name, q) ->
                try {
                    if (CamcorderProfile.hasProfile(idInt, q)) {
                        CamcorderProfile.get(idInt, q)?.let {
                            camcorder.add(CamcorderInfo(name, it.videoFrameWidth, it.videoFrameHeight, it.videoFrameRate, it.videoBitRate))
                        }
                    }
                } catch (e: Exception) { RynLog.w("CamcorderProfile $name gagal") }
            }
        }

        val manual = capInts.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)

        return CameraReport(
            id = id, facing = facing,
            sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: -1,
            hardwareLevel = hw, capabilities = caps,
            pixelArray = pa?.let { "${it.width}x${it.height}" } ?: "-",
            focalLengths = focals, minFocusDistance = minFocus, flash = flash,
            afModes = af, awbModes = awb,
            aeCompRange = aeRange?.let { "${it.lower}..${it.upper}" } ?: "-",
            aeCompStep = aeStep?.let { String.format(Locale.US, "%.3f EV", it.toFloat()) } ?: "-",
            manualSensor = manual,
            isoRange = if (iso != null) "${iso.lower}..${iso.upper}" + (if (manual) "" else " (tidak dapat dikontrol manual)") else "-",
            exposureTimeRange = if (exp != null) "${fmtExp(exp.lower)} .. ${fmtExp(exp.upper)}" + (if (manual) "" else " (tidak dapat dikontrol manual)") else "-",
            fpsRanges = fpsRanges.map { "${it.lower}-${it.upper}" },
            maxFps = maxFps,
            videoSizes = videoSizes.take(15).map { "${it.width}x${it.height}" },
            has1080pVideo = has1080,
            highSpeed = highSpeed, photoSizes = photoSizes, imageFormats = formats,
            ois = ois, eisModes = eisModes, hasEis = hasEis,
            hdrScene = hdrScene, dynamicRangeProfiles = dyn,
            raw = capInts.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW),
            zoomRange = zoom, physicalIds = physical, camcorder = camcorder,
            fps60Candidate = has1080 && fpsRanges.any { it.upper >= 60 }
        )
    }

    // ----------------------------------------------------------------- codecs

    private fun readCodecs(errors: MutableList<String>): List<CodecReport> {
        val wanted = setOf("video/avc", "video/hevc", "audio/mp4a-latm")
        val out = mutableListOf<CodecReport>()
        try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { it.isEncoder }.forEach { info ->
                info.supportedTypes.filter { it in wanted }.forEach { type ->
                    try {
                        val caps = info.getCapabilitiesForType(type)
                        val hw = Build.VERSION.SDK_INT >= 29 && info.isHardwareAccelerated
                        val vc = caps.videoCapabilities
                        val ac = caps.audioCapabilities
                        val details: String
                        val maxBr: Int
                        if (vc != null) {
                            val fps = try {
                                val r = vc.getSupportedFrameRatesFor(1920, 1080)
                                "${r.lower.toInt()}..${r.upper.toInt()}"
                            } catch (e: IllegalArgumentException) { "1080p tidak didukung" }
                            details = "max=${vc.supportedWidths.upper}x${vc.supportedHeights.upper}; fps@1080p=$fps"
                            maxBr = vc.bitrateRange.upper
                        } else if (ac != null) {
                            details = "sampleRates=${ac.supportedSampleRates?.joinToString(",") ?: "-"}; maxChannels=${ac.maxInputChannelCount}"
                            maxBr = ac.bitrateRange.upper
                        } else { details = "-"; maxBr = 0 }
                        out.add(CodecReport(info.name, type, hw, maxBr, details))
                    } catch (e: Exception) {
                        errors.add("Codec ${info.name}/$type: ${e.javaClass.simpleName}")
                    }
                }
            }
        } catch (e: Exception) {
            RynLog.e("Baca codec gagal", e)
            errors.add("MediaCodecList gagal: ${e.javaClass.simpleName}")
        }
        return out
    }

    // ---------------------------------------------------------------- sensors

    private fun readSensors(errors: MutableList<String>): List<SensorReport> {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        if (sm == null) { errors.add("SensorManager tidak tersedia"); return emptyList() }
        return listOf(
            "gyroscope" to Sensor.TYPE_GYROSCOPE,
            "gyroscope_uncalibrated" to Sensor.TYPE_GYROSCOPE_UNCALIBRATED,
            "accelerometer" to Sensor.TYPE_ACCELEROMETER,
            "rotation_vector" to Sensor.TYPE_ROTATION_VECTOR
        ).map { (label, type) ->
            val s = sm.getDefaultSensor(type)
            SensorReport(label, s != null, s?.name ?: "-", s?.vendor ?: "-", s?.maximumRange ?: 0f, s?.minDelay ?: 0)
        }
    }

    private fun readThermal(): String {
        if (Build.VERSION.SDK_INT < 29) return "tidak tersedia (API<29)"
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return "-"
        return when (pm.currentThermalStatus) {
            0 -> "NONE"; 1 -> "LIGHT"; 2 -> "MODERATE"; 3 -> "SEVERE"
            4 -> "CRITICAL"; 5 -> "EMERGENCY"; 6 -> "SHUTDOWN"; else -> "UNKNOWN"
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun fmtExp(ns: Long): String =
        if (ns >= 1_000_000_000L) String.format(Locale.US, "%.1fs", ns / 1e9)
        else if (ns <= 0L) "0" else "1/${(1e9 / ns).toLong()}s"

    private fun capName(i: Int) = when (i) {
        0 -> "BACKWARD_COMPATIBLE"; 1 -> "MANUAL_SENSOR"; 2 -> "MANUAL_POST_PROCESSING"
        3 -> "RAW"; 4 -> "PRIVATE_REPROCESSING"; 5 -> "READ_SENSOR_SETTINGS"
        6 -> "BURST_CAPTURE"; 7 -> "YUV_REPROCESSING"; 8 -> "DEPTH_OUTPUT"
        9 -> "CONSTRAINED_HIGH_SPEED_VIDEO"; 10 -> "MOTION_TRACKING"; 11 -> "LOGICAL_MULTI_CAMERA"
        12 -> "MONOCHROME"; else -> "CAP_$i"
    }

    private fun afName(i: Int) = when (i) {
        0 -> "OFF"; 1 -> "AUTO"; 2 -> "MACRO"; 3 -> "CONTINUOUS_VIDEO"
        4 -> "CONTINUOUS_PICTURE"; 5 -> "EDOF"; else -> "AF_$i"
    }

    private fun awbName(i: Int) = when (i) {
        0 -> "OFF"; 1 -> "AUTO"; 2 -> "INCANDESCENT"; 3 -> "FLUORESCENT"
        4 -> "WARM_FLUORESCENT"; 5 -> "DAYLIGHT"; 6 -> "CLOUDY_DAYLIGHT"
        7 -> "TWILIGHT"; 8 -> "SHADE"; else -> "AWB_$i"
    }

    private fun formatName(f: Int) = when (f) {
        ImageFormat.JPEG -> "JPEG"; ImageFormat.YUV_420_888 -> "YUV_420_888"
        ImageFormat.RAW_SENSOR -> "RAW_SENSOR"; ImageFormat.RAW10 -> "RAW10"
        ImageFormat.RAW12 -> "RAW12"; ImageFormat.PRIVATE -> "PRIVATE"
        ImageFormat.NV21 -> "NV21"; ImageFormat.HEIC -> "HEIC"
        else -> "FORMAT_$f"
    }
}
