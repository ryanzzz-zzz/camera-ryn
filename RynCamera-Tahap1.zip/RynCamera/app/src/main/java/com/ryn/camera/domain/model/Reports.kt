package com.ryn.camera.domain.model

data class CamcorderInfo(
    val quality: String, val width: Int, val height: Int, val fps: Int, val videoBitrateBps: Int
) {
    fun toMap(): Map<String, Any?> = linkedMapOf(
        "quality" to quality, "size" to "${width}x$height",
        "fps" to fps, "videoBitrateKbps" to videoBitrateBps / 1000
    )
}

data class CameraReport(
    val id: String,
    val facing: String,
    val sensorOrientation: Int,
    val hardwareLevel: String,
    val capabilities: List<String>,
    val pixelArray: String,
    val focalLengths: List<Float>,
    val minFocusDistance: Float,
    val flash: Boolean,
    val afModes: List<String>,
    val awbModes: List<String>,
    val aeCompRange: String,
    val aeCompStep: String,
    val manualSensor: Boolean,
    val isoRange: String,
    val exposureTimeRange: String,
    val fpsRanges: List<String>,
    val maxFps: Int,
    val videoSizes: List<String>,
    val has1080pVideo: Boolean,
    val highSpeed: List<String>,
    val photoSizes: List<String>,
    val imageFormats: List<String>,
    val ois: Boolean,
    val eisModes: List<String>,
    val hasEis: Boolean,
    val hdrScene: Boolean,
    val dynamicRangeProfiles: List<String>,
    val raw: Boolean,
    val zoomRange: String,
    val physicalIds: List<String>,
    val camcorder: List<CamcorderInfo>,
    /** Indikasi saja (AE range >= 60 + 1080p tersedia). Harus diverifikasi saat uji rekam. */
    val fps60Candidate: Boolean
) {
    fun toMap(): Map<String, Any?> = linkedMapOf(
        "cameraId" to id,
        "lensFacing" to facing,
        "sensorOrientation" to sensorOrientation,
        "hardwareLevel" to hardwareLevel,
        "capabilities" to capabilities,
        "sensorPixelArray" to pixelArray,
        "focalLengths(mm)" to focalLengths,
        "minFocusDistance(diopter)" to minFocusDistance,
        "flash" to flash,
        "autofocusModes" to afModes,
        "whiteBalanceModes" to awbModes,
        "exposureCompRange" to aeCompRange,
        "exposureCompStep" to aeCompStep,
        "manualSensorControl" to manualSensor,
        "isoRange" to isoRange,
        "exposureTimeRange" to exposureTimeRange,
        "aeTargetFpsRanges" to fpsRanges,
        "maxFps(AE)" to maxFps,
        "videoSizes(MediaRecorder)" to videoSizes,
        "has1080pVideo" to has1080pVideo,
        "highSpeedVideo" to highSpeed,
        "photoSizes(JPEG,top)" to photoSizes,
        "imageFormats" to imageFormats,
        "OIS(hardware)" to ois,
        "videoStabilizationModes" to eisModes,
        "EIS(native)" to hasEis,
        "HDR(scene mode)" to hdrScene,
        "dynamicRangeProfiles" to dynamicRangeProfiles,
        "RAW" to raw,
        "zoomRatioRange" to zoomRange,
        "physicalCameraIds" to physicalIds,
        "camcorderProfiles" to camcorder.map { it.toMap() },
        "fps60Candidate(1080p,unverified)" to fps60Candidate
    )
}

data class CodecReport(
    val name: String, val mime: String, val hardware: Boolean,
    val bitrateMaxBps: Int, val details: String
) {
    fun toMap(): Map<String, Any?> = linkedMapOf(
        "name" to name, "mime" to mime, "hardwareAccelerated" to hardware,
        "maxBitrateMbps" to String.format(java.util.Locale.US, "%.1f", bitrateMaxBps / 1_000_000.0),
        "details" to details
    )
}

data class SensorReport(
    val label: String, val available: Boolean, val name: String,
    val vendor: String, val maxRange: Float, val minDelayUs: Int
) {
    fun toMap(): Map<String, Any?> = linkedMapOf(
        "sensor" to label, "available" to available, "name" to name,
        "vendor" to vendor, "maxRange" to maxRange, "minDelayUs" to minDelayUs
    )
}

data class DeviceReport(
    val manufacturer: String, val brand: String, val model: String, val device: String,
    val hardware: String, val sdk: Int, val release: String, val abis: List<String>,
    val thermalStatus: String,
    val cameras: List<CameraReport>,
    val codecs: List<CodecReport>,
    val sensors: List<SensorReport>,
    val errors: List<String>,
    val timestamp: Long
) {
    fun toMap(): Map<String, Any?> = linkedMapOf(
        "app" to "Ryn Camera (Tahap 1)",
        "timestamp" to timestamp,
        "device" to linkedMapOf<String, Any?>(
            "manufacturer" to manufacturer, "brand" to brand, "model" to model,
            "device" to device, "hardware" to hardware,
            "android" to "$release (API $sdk)", "abis" to abis, "thermalStatus" to thermalStatus
        ),
        "cameras" to cameras.map { it.toMap() },
        "codecs" to codecs.map { it.toMap() },
        "sensors" to sensors.map { it.toMap() },
        "errors" to errors
    )
}
