# Ryn Camera - Tahap 1 (Fondasi + Camera Diagnostics)

Package `com.ryn.camera` · minSdk 26 · targetSdk 34 · Kotlin 1.9.24 · AGP 8.5.2 · Gradle 8.7 · JDK 17

## Isi Tahap 1
- Welcome → "Optimizing camera for your device..." → "Your camera profile is ready."
- `CapabilityDetector`: Camera2 (hardware level, FPS, resolusi, AF/AWB, AE comp, ISO/shutter, OIS, EIS, HDR, RAW, flash,
  focal length, format), CamcorderProfile, encoder H.264/HEVC/AAC (hardware?, bitrate maks), sensor gyro/accel, thermal.
- `RealmeC53Profile` + `GenericProfile`: batas aman (1080p30, bitrate, thermal, memori) yang SELALU di-clamp ke hasil deteksi.
- Halaman Camera Diagnostics + Export TXT/JSON (Storage Access Framework, tanpa izin storage).
- Tanpa permission INTERNET. Semua lokal.

## Build APK
1. Android Studio (Koala/2024.1+ atau lebih baru), JDK 17.
2. File → Open → pilih folder `RynCamera`. Tunggu Gradle Sync (butuh internet sekali).
   (Jika diminta, setujui pembuatan Gradle wrapper / pilih Gradle 8.7.)
3. Build → Build APK(s). Hasil: `app/build/outputs/apk/debug/app-debug.apk`.
4. Atau CLI (setelah wrapper ada): `./gradlew assembleDebug`.

## Setelah dijalankan di realme C53 NFC
Buka Camera Diagnostics → Export JSON, lalu kirim hasilnya ke saya. Tahap 2+ akan memakai data itu
(60 FPS, EIS native, HDR, dst. hanya diaktifkan jika benar-benar terdeteksi).

## Build via GitHub Actions
1. Buat repo GitHub, upload seluruh isi folder `RynCamera` (termasuk folder `.github`).
2. Push ke branch `main` -> tab **Actions** -> workflow **Build APK** berjalan otomatis (atau klik *Run workflow*).
3. Setelah hijau, buka run tersebut -> **Artifacts** -> unduh `RynCamera-debug-apk`, ekstrak, install `app-debug.apk`.
